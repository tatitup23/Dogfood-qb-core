local QBCore = exports['qb-core']:GetCoreObject()
local onDuty = false

-- Clock in/out at Cafe
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local ped = PlayerPedId()
        local pos = GetEntityCoords(ped)
        if #(pos - Config.CafeCoords) < 2.0 then
            DrawText3D(Config.CafeCoords, "[E] Clock " .. (onDuty and "Out" or "In") .. " as Dog Food Maker")
            if IsControlJustReleased(0, 38) then
                onDuty = not onDuty
                QBCore.Functions.Notify("You are now " .. (onDuty and "on" or "off") .. " duty!", "success")
                TriggerServerEvent('qb-dogfoodmaker:onduty', onDuty)
            end
        end
    end
end)

-- Crafting at Workbench
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local ped = PlayerPedId()
        local pos = GetEntityCoords(ped)
        if onDuty and #(pos - Config.Workbench) < 2.0 then
            DrawText3D(Config.Workbench, "[E] Craft Dog Food")
            if IsControlJustReleased(0, 38) then
                TriggerServerEvent('qb-dogfoodmaker:craft')
            end
        end
    end
end)

-- Deliver Dog Food
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local ped = PlayerPedId()
        local pos = GetEntityCoords(ped)
        if onDuty and #(pos - Config.Delivery) < 2.0 then
            DrawText3D(Config.Delivery, "[E] Deliver Dog Food")
            if IsControlJustReleased(0, 38) then
                TriggerServerEvent('qb-dogfoodmaker:deliver')
            end
        end
    end
end)

function DrawText3D(coords, text)
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(true)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = (string.len(text)) / 370
    DrawRect(coords.x, coords.y + 0.0125, 0.015 + factor, 0.03, 41, 11, 41, 68)
end