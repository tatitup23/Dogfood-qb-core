Locales = {
    ['not_enough_ingredients'] = "You don't have enough ingredients.",
    ['crafted_dog_food'] = "You crafted dog food!",
    ['delivered_dog_food'] = "Dog food delivered! You received $%s.",
    ['no_dog_food'] = "You have no dog food to deliver.",
    ['onduty'] = "You are now on duty!",
    ['offduty'] = "You are now off duty!"
}