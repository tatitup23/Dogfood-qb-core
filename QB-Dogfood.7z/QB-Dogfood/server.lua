local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent('qb-dogfoodmaker:onduty', function(status)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if status then
        Player.Functions.SetJob(Config.JobName, 0)
    else
        Player.Functions.SetJob("unemployed", 0)
    end
end)

RegisterNetEvent('qb-dogfoodmaker:craft', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player.Functions.RemoveItem(Config.Ingredients.meat.item, Config.Ingredients.meat.amount) and
       Player.Functions.RemoveItem(Config.Ingredients.grains.item, Config.Ingredients.grains.amount) then
        Player.Functions.AddItem(Config.DogFoodItem, 1)
        TriggerClientEvent('QBCore:Notify', src, "You crafted dog food!", "success")
    else
        TriggerClientEvent('QBCore:Notify', src, "You don't have enough ingredients.", "error")
    end
end)

RegisterNetEvent('qb-dogfoodmaker:deliver', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player.Functions.RemoveItem(Config.DogFoodItem, 1) then
        Player.Functions.AddMoney('cash', Config.DogFoodPayout)
        TriggerClientEvent('QBCore:Notify', src, "Dog food delivered! You received $" .. Config.DogFoodPayout, "success")
    else
        TriggerClientEvent('QBCore:Notify', src, "You have no dog food to deliver.", "error")
    end
end)