INSERT INTO `jobs` (name, label, whitelisted) VALUES
('dogfoodmaker', 'Dog Food Maker', 0);

INSERT INTO `job_grades` (job_name, grade, name, label, salary, skin_male, skin_female) VALUES
('dogfoodmaker', 0, 'dogfoodmaker', 'Dog Food Maker', 200, '{}', '{}');


INSERT INTO `qbcorejobs` (name, label, whitelisted) VALUES
('dogfoodmaker', 'Dog Food Maker', 0);

INSERT INTO `items` (name, label, weight, rare, can_remove, type, image) VALUES
('meat', 'Meat', 500, 0, 1, 'item', 'meat.png'),
('grains', 'Grains', 500, 0, 1, 'item', 'grains.png'),
('dogfood', 'Dog Food', 500, 0, 1, 'item', 'dogfood.png');