fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'UwU Cafe Pet Store Dog Food Maker Job for QBCore'
version '1.0.0'

shared_scripts {
    '@qb-core/shared/locale.lua',
    'locales/en.lua',
    'config.lua'
}

client_scripts {
    'client.lua'
}

server_scripts {
    '@qb-core/import.lua',
    'server.lua'
}